---
date: {{date}}
tags: [daily]
---

# {{date:dddd, MMMM D, YYYY}}

## Meetings


## Work Projects


## Personal Projects


## Ideas


## Claude Sessions


## Remember

