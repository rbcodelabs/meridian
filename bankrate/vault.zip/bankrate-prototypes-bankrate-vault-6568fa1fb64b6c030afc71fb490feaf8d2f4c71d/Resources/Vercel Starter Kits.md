# Vercel Starter Kits

All starter kits live in the **[bankrate-prototypes](https://github.com/bankrate-prototypes)** GitHub org and are deployed via **[Deploy Hub](https://deployhub.bankrate-prototypes.com)**. They share the same core stack: Next.js App Router, React 19, TypeScript, Tailwind v4, shadcn/ui, Prisma 7, Aurora DSQL.

## Which Kit to Use

| Kit | Repo | Auth | Database | Best For |
|---|---|---|---|---|
| **Starter Kit** | [starter-kit](https://github.com/bankrate-prototypes/starter-kit) | ✅ Auth0 v4 | Prisma 7 + Aurora DSQL | Default starting point — internal tools, greenfield apps |
| **Member Starter Kit** | [member-starter-kit](https://github.com/bankrate-prototypes/member-starter-kit) | ✅ Auth0 v4 | Prisma 7 + Aurora DSQL | Consumer-facing products, member dashboards, multi-route apps |

**Rule of thumb:** Start with Starter Kit. Upgrade to Member Starter Kit when you need consumer-facing routes, per-user state, or a "show don't tell" demo.

Both kits require Auth0 — without authentication any deployed Vercel URL is fully public.

## Starter Kit

The default starting point. Auth0-protected, full deployment pipeline, build fails if tests fail.

**Includes:**
- Auth0 v4 with fail-closed middleware
- Prisma 7 + Aurora DSQL
- Bankrate Ledger component registry (`npx shadcn add @bankrate-ledger/...`)
- Vercel AI SDK
- Docker multi-stage build + Terraform
- New Relic observability
- Vitest test suite (build is gated — `pnpm test && next build`)
- `/admin` route protected behind admin email allowlist
- Biome linter/formatter

## Member Starter Kit

Everything in Starter Kit, plus a working member dashboard and financial planning routes. The best reference for what a Bankrate consumer product looks like.

**Additional includes:**
- Auth0 user profile integration
- Per-user state (DB + client-side)
- Financial planning routes: `/plan/debt`, `/plan/savings`, `/plan/retirement`, `/plan/home`, `/plan/investing`, `/plan/emergency-fund`
- Financial domain logic: affordability, compound interest, loan, mortgage, 401k calculators
- `/tools`, `/profile`, `/settings`, `/mortgage` routes

## Deploying a New Project

New projects are created and deployed through **[Deploy Hub](https://deployhub.bankrate-prototypes.com)**:

1. Go to Deploy Hub → **New Project**
2. Pick a template (Starter Kit or Member Starter Kit)
3. Give the project a slug — this becomes the DB schema name
4. Deploy — Vercel + Aurora DSQL are provisioned automatically

## Reference Repos (Not Templates)

- **`v0-prisma-dsql-starter`** — Living reference for Prisma 7 + Aurora DSQL patterns. Has an in-app `/guide` page. Not a project template.
- **`v0-brand-starter-kit`** — Archived. Superseded by Starter Kit.
