# Agentic PM Playbook

The **Agentic PM Playbook** is a framework for running AI-augmented product management — OST (Opportunity Solution Trees), signal synthesis, experiment design, and investment gating — using Claude Code agents and skills.

## What It Is

The playbook installs a set of specialized Claude agents and skills that work alongside you:

| Agent / Skill | What it does |
|---|---|
| `pm-coach` | Thinking partner for PM decisions — OST framing, discovery coaching, outcomes vs. output |
| `pm-setup` | One-time configuration — writes `pm-config.md` so every agent knows your context |
| `ost-workflow` | Creates and updates Opportunity Solution Trees in your vault |
| `pm-signal-synthesis` | Clusters customer signals into OST-ready opportunity groups |
| `investment-gate` | Runs a progressive investment framework check before committing to a solution |
| `agentic-pm` | General PM coaching grounded in the playbook |

## Install

```bash
git clone https://github.com/bankrate-prototypes/agentic-pm-playbook
cd agentic-pm-playbook
./setup.sh --dry-run   # preview what will be installed
./setup.sh             # install agents + skills into ~/.claude/
```

Restart Claude Code after setup finishes (`exit`, then `claude` again).

**Verify:** In a Claude Code session, type:
```
use the pm-coach skill
```
It should respond as a PM thinking partner.

## First-Time Configuration

Run this once inside your product workspace folder:

```
Run the pm-setup skill to configure my notes system, issue tracker, and current desired outcome.
```

Answer its questions — especially **desired outcome** (a measurable behavior change, not a feature). This writes `pm-config.md`, which every agent reads for context.

## Vault Bridge (sync playbook docs into Obsidian)

To bring the playbook's reference docs into your vault:

1. Obsidian → **Settings → Vault Bridges → Add Bridge**
2. Set **Repo path** to the cloned folder: `~/GitHub/agentic-pm-playbook`
3. Set **Vault path** to `Products/Playbooks/Agentic PM`
4. Click **Sync now**

The full playbook, training modules, and OST reference will appear inside your vault and be searchable alongside your notes.

## Day-to-Day Usage

**Weekly signal synthesis:**
```
Synthesize this batch of customer signals into OST-ready opportunity clusters:
[paste tickets / quotes / review excerpts]
```

**OST update:**
```
Use ost-workflow to update my OST with the insights from today's user interviews.
```

**Investment gate check:**
```
Run an investment-gate check on this solution before we commit to building it.
```

## Full Documentation

The complete playbook lives in `Products/Playbooks/Agentic PM/` in this vault (after bridge sync), or online at [github.com/bankrate-prototypes/agentic-pm-playbook](https://github.com/bankrate-prototypes/agentic-pm-playbook).
