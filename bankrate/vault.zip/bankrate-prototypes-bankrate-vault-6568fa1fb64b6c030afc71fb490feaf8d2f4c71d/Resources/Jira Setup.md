# Jira Setup

Bankrate engineering uses **Jira** (Atlassian) for sprint and backlog tracking. Claude Code and the Obsidian Claude Threads plugin can both connect to Jira to surface issues, update tickets, and run backlog health reports.

## Connect Claude Threads (Obsidian) to Jira

Add these three secrets in **Obsidian → Settings → Claude Threads → Secret environment variables**:

| Secret name | Value |
|---|---|
| `JIRA_API_TOKEN` | Your personal API token (see below) |
| `JIRA_EMAIL` | The email address on your Atlassian account |
| `JIRA_BASE_URL` | `https://redventures.atlassian.net` |

**Get your API token:**
1. Go to [id.atlassian.com/manage-profile/security/api-tokens](https://id.atlassian.com/manage-profile/security/api-tokens)
2. Click **Create API token** → label it "Obsidian Claude Threads" → Create
3. Copy the token — you won't see it again

**Verify:** Open a Claude Thread and ask: *"List my 5 most recent Jira issues assigned to me."* A working connection returns issues; an auth error means one of the three secrets is wrong — check `JIRA_EMAIL` and `JIRA_BASE_URL` first.

## Connect Claude Code (terminal) to Jira

The same three values need to be in your shell environment. Add to `~/.zshenv`:

```bash
export JIRA_API_TOKEN="your-token"
export JIRA_EMAIL="you@bankrate.com"
export JIRA_BASE_URL="https://redventures.atlassian.net"
```

Then `source ~/.zshenv` or open a new terminal.

## Key Jira Boards

| Squad | Board |
|---|---|
| Ask / SEO | [board link] |
| Cards | [board link] |
| Deposits | [board link] |
| Insurance | [board link] |
| Investments | [board link] |
| Mortgages | [board link] |
| Personal Finance | [board link] |
| Platform | [board link] |

> Board links: find them at `https://redventures.atlassian.net/jira/software/projects` — filter by your squad name.

## Useful Claude Prompts

Once connected, try these in a Claude Thread:

```
What are my open Jira issues due this sprint?
```

```
Use the br-backlog-health skill to run a sprint health report for the [squad] board.
```

```
Show me all tickets in the [PROJECT] backlog that have no story points.
```
