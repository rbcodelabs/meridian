# Bankrate Vault

Starter Obsidian vault for the Bankrate AI developer environment, installed by **Bankrate Meridian**.

## Structure

| Folder | Purpose |
|---|---|
| `Daily/` | Daily notes (created automatically by Periodic Notes plugin) |
| `Projects/` | One note per project — link issues, docs, and threads here |
| `Resources/` | Reference docs for Bankrate tools and workflows |
| `Templates/` | Note templates used by Templater and Periodic Notes |

## Resources

Quick-start guides are in `Resources/`:

- **[Vercel Starter Kits](Resources/Vercel%20Starter%20Kits.md)** — Which kit to use, how to deploy via Deploy Hub
- **[Jira Setup](Resources/Jira%20Setup.md)** — Connect Claude Threads and Claude Code to Jira
- **[Agentic PM Playbook](Resources/Agentic%20PM%20Playbook.md)** — Install and use the PM agent skills

## Plugins

Pre-configured and bundled by Meridian:
- **BRAT** — plugin installer for beta/GitHub plugins
- **Claude Threads** — Claude inside Obsidian
- **Vault Bridges** — sync local repos/folders into your vault
- **Calendar**, **Periodic Notes**, **Templater**, **Dataview**

## Contributing

Add team-wide templates, resources, or `.obsidian/` config to this repo and open a PR.
Meridian will pull the latest when new team members run setup.
